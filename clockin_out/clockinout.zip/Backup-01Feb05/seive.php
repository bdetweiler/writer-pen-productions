<?php

echo '1<br>';
$seive[] = null;
for($i = 2; $i <= 9,999,999,999; ++$i)
{
    $seive[$i - 2] = $i;
}
for($k = 2; $k <= sqrt(9,999,999,999.0); ++k)
{
    if($seive[$k - 2] != 0)
    {
       while(



?>

